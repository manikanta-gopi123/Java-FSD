package Problem4;

import java.util.Scanner;

public class ParaMetarizedConstructor {
	ParaMetarizedConstructor(double length, double breath,double height)
	{
		double volume=length*breath*height;
		System.out.println("Volume of the BOX is "+volume);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParaMetarizedConstructor  obj=new ParaMetarizedConstructor(5, 5, 5);

	}

}
