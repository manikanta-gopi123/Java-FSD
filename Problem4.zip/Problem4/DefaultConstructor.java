package Problem4;

public class DefaultConstructor {
	DefaultConstructor(){
		double length=5;
		double breath =5;
		double height=5;
		double volume=length*breath*height;
		System.out.println("Volume of Box is : "+volume);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultConstructor obj=new DefaultConstructor();
		

	}

}
