package Problem6;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String> HashMap=new HashMap<>();
		HashMap.put(0, "Gopi");
		HashMap.put(1, "GopiManikanta");
		HashMap.put(2, "sai");
		HashMap.put(3, "Ravi");
		HashMap.put(4, "Sandeep");
		HashMap.put(5, "Hemanth");
		System.out.println("HASH MAP");
		System.out.println("Elements in the HashMap are : "+HashMap);
		HashMap.put(6, "Nadikatla");
		System.out.println("Elements in the HashMap are : "+HashMap);
		System.out.println(HashMap.size());
		System.out.println(HashMap.isEmpty());
		
		
		
		System.out.println("=========================================================");
		System.out.println("TREE MAP");
		Map<Integer,String> TreeMap=new TreeMap<>();
		TreeMap.put(1, "Gopi");
		TreeMap.put(0, "GopiManikanta");
		TreeMap.put(2, "sai");
		TreeMap.put(5, "Ravi");
		TreeMap.put(4, "Sandeep");
		TreeMap.put(3, "Hemanth");
		System.out.println("Elements in the HashMap are : "+TreeMap);
		TreeMap.put(6, "Nadikatla");
		System.out.println("Elements in the HashMap are : "+TreeMap);
		System.out.println(TreeMap.size());
		System.out.println(TreeMap.isEmpty());
		
		
		
		System.out.println("=========================================================");
		System.out.println("LINKED HASH MAP");
		Map<Integer,String> LinkedHashMap=new LinkedHashMap<>();
		LinkedHashMap.put(1, "Gopi");LinkedHashMap.put(0, "GopiManikanta");
		LinkedHashMap.put(2, "sai");
		LinkedHashMap.put(5, "Ravi");
		LinkedHashMap.put(4, "Sandeep");
		LinkedHashMap.put(3, "Hemanth");
		System.out.println("Elements in the HashMap are : "+LinkedHashMap);
		LinkedHashMap.put(6, "Nadikatla");
		System.out.println("Elements in the HashMap are : "+LinkedHashMap);
		System.out.println(LinkedHashMap.size());
		System.out.println(LinkedHashMap.isEmpty());
		

	}

}
