package com.hibernate;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        Student s=new Student();
        s.setRno("1");
         s.setName("Gopi");
         s.setRno("2");
         s.setName("Mani");
         s.setRno("3");
         s.setName("Manikanta");
        session.save(s);
        transaction.commit();
        session.close();
        sessionFactory.close();

	}

}
