package com.example;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
@org.springframework.stereotype.Controller
public class Controller {
	//This is way of printing data in virtual page
	@ResponseBody
	@RequestMapping("/sum")
	public String sum(HttpServletRequest request,HttpServletResponse response) {
		int res=Integer.parseInt(request.getParameter("num1")+request.getParameter("num2"));
		return "the result is "+res;
	}


//This is another way of printing data in physical page
	@RequestMapping("/sub")
	public ModelAndView displaySub(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		
		int res= Integer.parseInt(request.getParameter("num1"))-Integer.parseInt(request.getParameter("num2"));
		
		mv.setViewName("display.jsp");
		mv.addObject("result", res);
		return mv;

		
	}
	

}
