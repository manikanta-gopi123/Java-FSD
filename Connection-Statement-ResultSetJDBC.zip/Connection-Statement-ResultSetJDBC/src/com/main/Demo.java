package com.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.jdbc.JdbcConstantPool;

public class Demo {
public static void main(String[] args) throws SQLException {

	            Connection connection = DriverManager.getConnection(JdbcConstantPool.Driver_Url,JdbcConstantPool.username,JdbcConstantPool.password);;
	            Statement statement = connection.createStatement();
	            String sqlQuery = "SELECT * FROM employees";
	            ResultSet resultSet = statement.executeQuery(sqlQuery);
	            while (resultSet.next()) {
	                int employeeId = resultSet.getInt("id");
	                String employeeName = resultSet.getString("name");
	                double employeeSalary = resultSet.getDouble("salary");
	                System.out.println("Employee ID: " + employeeId);
	                System.out.println("Employee Name: " + employeeName);
	                System.out.println("Employee Salary: " + employeeSalary);
	                System.out.println();
	            }
	            resultSet.close();
	            statement.close();
	            connection.close();

	        } 
	    }
	


