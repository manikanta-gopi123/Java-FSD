package com.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.jdbc.JdbcConstantPool;

public class ProductRetrieval {

	public static void main(String[] args) throws SQLException {
		 Connection connection = DriverManager.getConnection(JdbcConstantPool.Driver_Url,JdbcConstantPool.username
				 ,JdbcConstantPool.password);
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter Product ID To Retreive");
		  int productIdToRetrieve =sc.nextInt();
	            String sqlQuery = "SELECT product_name, price, description FROM products WHERE product_id = ?";
	            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
	            preparedStatement.setInt(1, productIdToRetrieve);

	            ResultSet resultSet = preparedStatement.executeQuery();

	            if (resultSet.next()) {
	                String productName = resultSet.getString("product_name");
	                double price = resultSet.getDouble("price");
	                String description = resultSet.getString("description");

	                System.out.println("Product Name: " + productName);
	                System.out.println("Price: $" + price);
	                System.out.println("Description: " + description);
	            } else {
	                System.out.println("Product not found for ID: " + productIdToRetrieve);
	            }

	        }
	    

	}


