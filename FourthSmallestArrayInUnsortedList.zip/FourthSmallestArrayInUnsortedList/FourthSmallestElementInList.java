package com.FourthSmallestArrayInUnsortedList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class FourthSmallestElementInList {

	public static void main(String[] args) {
		        List<Integer> unsortedList = new ArrayList<>();
		        Scanner scanner = new Scanner(System.in);

		        System.out.println("Enter the list of integers (one integer per line, type 'done' when finished):");

		        // Read integers until the user enters "done"
		        while (scanner.hasNextInt()) {
		            unsortedList.add(scanner.nextInt());
		        }

		        int fourthSmallest = findFourthSmallestElement(unsortedList);

		        System.out.println("The fourth smallest element is: " + fourthSmallest);
		    }

		    static int findFourthSmallestElement(List<Integer> list) {
		        if (list.size() < 4) {
		            // Handle the case when the list doesn't have at least four elements.
		            System.out.println("The list doesn't have at least four elements.");
		            return -1;
		        }

		        // Sort the list in ascending order
		        Collections.sort(list);

		        // Return the fourth element (index 3 since indices start at 0).
		        return list.get(3);
		    }
		


	}


