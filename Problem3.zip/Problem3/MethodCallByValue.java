package Problem3;

public class MethodCallByValue {
	public static void add(int num1,int num2) {
		int result=num1+num2;
		
		System.out.println("This is Using Call By Value "+result);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodCallByValue obj=new MethodCallByValue();
		add(25, 30);

	}

}
