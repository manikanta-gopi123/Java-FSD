package Problem3;

public class MethodCallByReferance {
	public static void add(int num1,int num2) {
		int result=num1+num2;
		
		System.out.println("This is Using Call By Referance "+result);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodCallByReferance obj=new MethodCallByReferance();
		obj.add(9, 30);

	}

}
