package Problem16;

public class NotEligibleForVoting extends Exception {
	public String toString() {
		return "NotEligibleForVoting";
	}

}
