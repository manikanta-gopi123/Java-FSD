package Problem16;

import java.util.Scanner;

public class Demo {
	public void age(int age) throws NotEligibleForVoting {
		if(age>=18) {
			System.out.println("Eligible for Voting");
		}
		else {
			throw new  NotEligibleForVoting();
		}
		
		
	}

	public static void main(String[] args) throws NotEligibleForVoting {
		// TODO Auto-generated method stub
		 Demo obj=new  Demo();
		 System.out.println("Enter Age");
		 Scanner sc=new Scanner(System.in);
		 int age=sc.nextInt();
		 obj.age(age);
		
	}

}
