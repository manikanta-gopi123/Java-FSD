package Problem15;

public class TryCatchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {
				25,30,9,48,75};
		try {
		System.out.println(arr[9]);	
		int num=25/0;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		

	}

}
