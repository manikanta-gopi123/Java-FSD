package com.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Crossing {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int Sno;
	private String Name;
	private String Address;
	private String LandMark;
	private String TrainSchedule;
	private String PersonInCharge;
	private String Status;
	public int getSno() {
		return Sno;
	}
	public void setSno(int sno) {
		Sno = sno;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getLandMark() {
		return LandMark;
	}
	public void setLandMark(String landMark) {
		LandMark = landMark;
	}
	public String getTrainSchedule() {
		return TrainSchedule;
	}
	public void setTrainSchedule(String trainSchedule) {
		TrainSchedule = trainSchedule;
	}
	public String getPersonInCharge() {
		return PersonInCharge;
	}
	public void setPersonInCharge(String personInCharge) {
		PersonInCharge = personInCharge;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
		
}
