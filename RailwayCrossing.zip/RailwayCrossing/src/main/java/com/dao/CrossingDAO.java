package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dbutil.DbUtil;
import com.pojo.Crossing;



public class CrossingDAO {
	public int crossing(Crossing crossing) {
		Session session=DbUtil.dbConn();
		Transaction trans=session.beginTransaction();
		int value=(Integer) session.save(crossing);
		trans.commit();
		session.close();
		return value;
		
	}
	
	public List<Crossing> display(){
		Session session=DbUtil.dbConn();
		Transaction trans=session.beginTransaction();
		Query query=session.createQuery("from Crossing");
		List<Crossing> list=query.list();
		trans.commit();
		session.close();
		return list;
	}
	
	public List<Crossing> delete(Crossing crossing){
		Session session=DbUtil.dbConn();
		Transaction trans=session.beginTransaction();
		session.delete(crossing);
		trans.commit();
		session.close();
		return display();
	}

}
