package com.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dbutil.DbUtil;
import com.pojo.Register;


public class RegisterDAO {
	public int register(Register register) {
		Session session=DbUtil.dbConn();
		Transaction trans=session.beginTransaction();
		int value=(Integer) session.save(register);
		trans.commit();
		session.close();
		return value;
		
	}
	

}
