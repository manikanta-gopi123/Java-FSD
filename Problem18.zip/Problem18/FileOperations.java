package Problem18;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileOperations {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f=new File("input");//creating File
		f.createNewFile();
		System.out.println("File Created");
		
		
		 FileWriter fi=new FileWriter("input");//writing content into File
		 fi.write("Hi Gopi");
		 fi.close();
		 System.out.println("Data Entered SucessFully into the file");
		 
		 FileReader fo=new FileReader("input");//Reading Content From File
		 BufferedReader bufferedReader = new BufferedReader(fo);
         String line;
         System.out.println("Reading from the file:");
         while ((line = bufferedReader.readLine()) != null)
         {
             System.out.println(line);
         }
         fo.close();
         FileWriter updater = new FileWriter(f, true); // Updating the file
         updater.write("\nAppending more content to the file.");
         updater.close();
         System.out.println("Content updated in the file.");
         
         FileReader reader2 = new FileReader(f);// Reading again after update
         BufferedReader bufferedReader2 = new BufferedReader(reader2);
         String line2;
         System.out.println("Reading from the file after update:");
         
         while ((line2 = bufferedReader2.readLine()) != null) 
         {
             System.out.println(line2);
         }
         reader2.close();

         
         if (f.delete())// Deleting the file
         {
             System.out.println("File deleted successfully.");
         } 
         else 
         {
             System.out.println("Failed to delete the file.");
         }
     } 
		
		

}
