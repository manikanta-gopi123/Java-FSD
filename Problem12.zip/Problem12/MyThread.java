package Problem12;

public class MyThread extends Thread{
	public void run() {
		System.out.println("My Current Thread Executed SucessFully............");
		System.out.println("Thank You");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThread  obj=new MyThread ();
		obj.run();

	}

}
