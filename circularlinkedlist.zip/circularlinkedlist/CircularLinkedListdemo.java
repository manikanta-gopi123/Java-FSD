package com.circularlinkedlist;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    private Node head;

    public SortedCircularLinkedList() {
        head = null;
    }

   
    public void insertSorted(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            head.next = head;
            return;
        }

        Node current = head;
        Node prev = null;

        
        do {
            prev = current;
            current = current.next;
        } while (current != head && current.data < data);

        
        prev.next = newNode;
        newNode.next = current;

        
        if (prev == head && data < current.data) {
            head = newNode;
        }
    }

    
    public void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " -> ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
public static class CircularLinkedListdemo {

	public static void main(String[] args) {
		SortedCircularLinkedList list = new SortedCircularLinkedList();

        list.insertSorted(10);
        list.insertSorted(5);
        list.insertSorted(20);
        list.insertSorted(1);

        System.out.println("Sorted Circular Linked List:");
        list.display();

	}

}
}
