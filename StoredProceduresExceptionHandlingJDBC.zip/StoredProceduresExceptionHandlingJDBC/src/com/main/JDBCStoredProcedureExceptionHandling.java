package com.main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.CallableStatement;
import java.sql.SQLException;

import com.jdbc.JdbcConstantPool;
public class JDBCStoredProcedureExceptionHandling {
	
public static void main(String[] args) throws SQLException {
	        Connection connection = DriverManager.getConnection(JdbcConstantPool.Driver_Url,JdbcConstantPool.username
	        		,JdbcConstantPool.password);
	            String storedProcedure = "{CALL get_employee(?, ?, ?)}";
	            CallableStatement callableStatement = connection.prepareCall(storedProcedure);
	            int employeeId = 1;
	            callableStatement.setInt(1, employeeId);
	            callableStatement.registerOutParameter(2, java.sql.Types.VARCHAR);
	            callableStatement.registerOutParameter(3, java.sql.Types.DECIMAL);  
	            callableStatement.execute();
	            String employeeName = callableStatement.getString(2);
	            double employeeSalary = callableStatement.getDouble(3);
	            System.out.println("Employee Name: " + employeeName);
	            System.out.println("Employee Salary: " + employeeSalary);
	        } 
	    
	}


