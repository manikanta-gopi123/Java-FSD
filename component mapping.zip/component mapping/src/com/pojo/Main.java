package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        // Create a person with an embedded address
        Person person = new Person();
        person.setName("John Doe");

        Address address = new Address();
        address.setCity("City1");
        address.setStreet("Street1");
        address.setZipCode("12345");

        person.setAddress(address);

        session.save(person);

        transaction.commit();
        session.close();

        // Retrieve the person with the embedded address in a new session
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();

        Person retrievedPerson = session.get(Person.class, person.getId());

        // Access the embedded address
        Address retrievedAddress = retrievedPerson.getAddress();
        System.out.println("Retrieved Address: " + retrievedAddress.getCity() + ", " +
                retrievedAddress.getStreet() + ", " + retrievedAddress.getZipCode());

        transaction.commit();
        session.close();

        sessionFactory.close();

	}

}
