package Problem7;

public class OuterClass {
	private String str="Welcome ";
	public class InnerClass{
		void display() {
			System.out.println(str+"Lets Start java Learning");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass out=new OuterClass();
		OuterClass.InnerClass in=out.new InnerClass();
		in.display();

	}

}
