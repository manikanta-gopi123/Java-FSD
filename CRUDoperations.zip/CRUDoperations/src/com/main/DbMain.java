
package com.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.dao.ProductDAO_Impl;
import com.pojo.Product;

public class DbMain {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Scanner sc=new Scanner(System.in);
		//working data
		ProductDAO_Impl dao=null;
		Product product=null;
		while(true) {
			System.out.println("Menu \n 1. add Product \n 2.delete product \n 3. update product \n 4. retrive product \n 5.exit");
			System.out.println("enter the choice ");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:product=new Product();
			System.out.println("enter product id ");
			product.setPid(sc.nextInt());
			System.out.println("enter product name");
			product.setPname(sc.next());
			System.out.println("enter product cost");
			product.setCost(sc.nextInt());
			dao=new ProductDAO_Impl();
			if(dao.addProduct(product)>0) {
				System.out.println("product got inserted with details "+product);
			}
			break;
			case 2:
				product=new Product();
				System.out.println("Enter Product ID to delete");
				product.setPid(sc.nextInt());
				/*if(dao.deleteProduct(product)==pid) {
					System.out.println("product got inserted with details "+product);
				}*/
				System.out.println("Product Deleted Sucessfully.....");
				break;
			case 3:
				product=new Product();
				System.out.println("enter New product name");
				product.setPname(sc.next());
				System.out.println("enter product id ");
				product.setPid(sc.nextInt());
				break;
			case 4:  
				dao=new ProductDAO_Impl();
				List<Product> productlist=dao.selectProducts();
			for(Product products:productlist) {
				System.out.println(products);
			}
			break;
			case 5:System.exit(0);
			break;
			}
		}
	}
}