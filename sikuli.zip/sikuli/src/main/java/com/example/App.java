package com.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws FindFailed, InterruptedException {
    	//register the webdriver =>browser vendor 
    			WebDriverManager.chromedriver().setup();
    			//creating an object to the object
    			WebDriver wd=new ChromeDriver();
    			//maximize the browser
    			wd.manage().window().maximize();

    			//webpage timebound 

			//go to browser and open this url 
    			wd.get("https://www.ilovepdf.com/pdf_to_word");

    			Screen sc=new Screen();
    			Pattern p1=new Pattern("F:\\3.png");
    			sc.click(p1);
    			Pattern p2=new Pattern("F:\\4.png");
    			sc.type(p2,"Downloads:\\Payslip_Nov2023.pdf");
    			Pattern p3=new Pattern("F:\\5.png");
    			sc.click(p3);
    			Thread.sleep(2000);
    			Pattern p4=new Pattern("F:\\6.png");
    			sc.click(p4);
    }
}
