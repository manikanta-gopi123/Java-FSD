package com.stack;

import java.util.LinkedList;
import java.util.Stack;

public class StackImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> s =new Stack<>();
		s.add("Gopi");
		s.add("Manikanta");
		s.add("Nadikatla");
		s.add("Hemanth");
		System.out.println("Elements Present in the stack are : "+ s);
		String str=s.remove(2);
		System.out.println("The Element Removed from the stack are "+str);
		s.add("Sandeep");
		System.out.println("Updated stack is "+ s);
		

	}

}
