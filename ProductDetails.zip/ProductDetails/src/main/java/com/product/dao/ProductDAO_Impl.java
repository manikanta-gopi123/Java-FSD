package com.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jdbc.JdbcUtil;
import com.product.pojo.Product;

public class ProductDAO_Impl implements ProductDAO{

	public int insert(Product product) throws ClassNotFoundException, SQLException {
		Connection conn=JdbcUtil.conn();
		if(conn!=null) {
			System.out.println("connection established with dB..!");
		}
		
		String sql ="insert into Product values(?,?,?)";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1,product.getPid());
		ps.setString(2, product.getPname());
		ps.setString(3, product.getPcost());
		return ps.executeUpdate();
	}

	public List<Product> displayallProducts() throws ClassNotFoundException, SQLException {
		Connection conn=JdbcUtil.conn();
		if(conn!=null) {
			System.out.println("connection established with dB..!");
		}
		
		String sql="select * from product";
		PreparedStatement ps=conn.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		List<Product> list=new ArrayList();
		
		while(rs.next()) {
			Product product=new Product();
			product.setPid(rs.getString("pid"));
			product.setPname(rs.getString("pname"));
			product.setPcost(rs.getString("pcost"));
			list.add(product);
			
		}
		return list;
	}

}
