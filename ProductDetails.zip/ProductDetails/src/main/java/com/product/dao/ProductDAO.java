package com.product.dao;

import java.sql.SQLException;
import java.util.List;

import com.product.pojo.Product;

public interface ProductDAO {
	public int insert(Product product) throws ClassNotFoundException, SQLException;
	public List<Product> displayallProducts() throws ClassNotFoundException, SQLException;

}
