package com.product.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.product.pojo.Product;

public class DisplayProduct {
	public static void displayProducts(List<Product> list,HttpServletResponse response) throws IOException {
		PrintWriter pw=response.getWriter();
		pw.print("<a href='index.html'>To Add Another Product click here ..!</a>");
		pw.print("<h1>Product Detaila</h1>");
		pw.print("<table border='1'>")	;
		pw.print("<tr><th>Product Id</th><th>Product Name</th><th>Product Cost</th>");

		for(Product product:list) {

			pw.print("<tr><td>"+product.getPid()+"</td>"+"<td>"+product.getPname()+"</td>"+"<td>"+product.getPcost()+"</td></tr>");	

		}
		pw.print("</table>");	
	}

	
}
