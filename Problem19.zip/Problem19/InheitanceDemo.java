package Problem19;
class Bike{
	int speed=160;
	public void speed() {
		System.out.println(speed);
	}
class Shine extends Bike{
	public void speed() {
		System.out.println(speed+60);
	}
	
}
}
public class InheitanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shine obj=new Shine();
		

	}

}
