package Problem19;
class Animal
{
    public void makeSound()
    {
        System.out.println("Some generic sound");
    }
}

class Dogs extends Animal 
{
    @Override
    public void makeSound() 
    {
        System.out.println("Woof!");
    }
}

class Cat extends Animal 
{
    @Override
    public void makeSound()
    {
        System.out.println("Meow!");
    }
}
public class Polymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal animal1 = new Dogs();
        Animal animal2 = new Cat();

        animal1.makeSound(); 
        animal2.makeSound(); 

	}

}
