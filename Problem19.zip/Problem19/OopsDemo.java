package Problem19;
class Dog{
	String name;
	String Breed;
	int age;
	public Dog(String name, String breed, int age) {
		super();
		this.name = name;
		Breed = breed;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBreed() {
		return Breed;
	}
	public void setBreed(String breed) {
		Breed = breed;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Dog [name=" + name + ", Breed=" + Breed + ", age=" + age + "]";
	}
	
}
public class OopsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog obj=new Dog("Sai","Lab", 25);
		System.out.println("Name of the Dog"+obj.getName());
		System.out.println("Breed of the Dog"+obj.getBreed());
		System.out.println("Age of the Dog"+obj.getAge());

	}

}
