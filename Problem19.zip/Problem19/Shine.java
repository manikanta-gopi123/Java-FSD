package Problem19;

public class Shine {

}
