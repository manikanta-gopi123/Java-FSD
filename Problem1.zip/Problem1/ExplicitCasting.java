package Problem1;

import java.util.Scanner;

public class ExplicitCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Explicit type casting");
		double d=25.00;
		int n=(int)d;
		System.out.println(n);
		byte b=(byte)d;
		System.out.println(b);
		char c=(char)d;
		System.out.println(c);
		short s=(short)d;
		System.out.println(s);
		

	}

}
