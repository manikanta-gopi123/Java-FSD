package Problem1;

import java.util.Scanner;

public class ImplicitCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Implicit Type Casting");
		int num=25;
		double di=num;
		System.out.println(di);
		byte b=1;
		double d=b;
		System.out.println(d);
		char c='b';
		int n=c;
		System.out.println(n);
		float f=25.30f;
		double df=f;
		System.out.println(df);
	
	}

}
