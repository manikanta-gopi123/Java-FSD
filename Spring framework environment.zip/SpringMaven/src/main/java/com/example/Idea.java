package com.example;

public class Idea implements Sim{

	@Override
	public void typeOfSim() {

System.out.println("This is Idea");
		
	}

	@Override
	public void Datatypeofsim() {

System.out.println("Idea 5G");
		
	}

	

}
