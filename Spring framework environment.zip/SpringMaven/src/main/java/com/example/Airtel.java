package com.example;

public class Airtel implements Sim{

	@Override
	public void typeOfSim() {

System.out.println("This is Airtel");
		
	}

	@Override
	public void Datatypeofsim() {

System.out.println("Airtel 5G");
		
	}



}
