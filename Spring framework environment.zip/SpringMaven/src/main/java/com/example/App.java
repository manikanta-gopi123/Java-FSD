package com.example;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //ApplicationContext ac= new ClassPathXmlApplicationContext("spring.xml");
    	ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
        Airtel airtel=ac.getBean(Airtel.class);
        airtel.Datatypeofsim();
        airtel.typeOfSim();
        Idea idea=ac.getBean(Idea.class);
        idea.Datatypeofsim();
        idea.typeOfSim();
    }
}
