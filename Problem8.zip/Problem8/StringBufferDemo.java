package Problem8;

import java.util.Scanner;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		String old_string=sc.nextLine();
		StringBuffer new_string=new StringBuffer(old_string);
		System.out.println("New String is"+old_string);
		System.out.println("Old String is"+new_string);
		System.out.println(new_string.capacity());
		System.out.println(new_string.append("Hello"));
		System.out.println(new_string.insert(3, "G"));

	}

}
