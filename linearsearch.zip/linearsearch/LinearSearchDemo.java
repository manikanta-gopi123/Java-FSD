package com.linearsearch;

import java.util.Arrays;
import java.util.Scanner;

public class LinearSearchDemo {

	public static void main(String[] args) {
				int arr[]=new int[] {
						25,30,9,48,75};
				Arrays.sort(arr);//This is an inbuilt method to sort array 
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter Key to search");
				int key=sc.nextInt();
				int flag=0;
				int i=0;
				for(i=0;i<arr.length;i++) {
					if(arr[i]==key) {
						flag=1;
						break;
					}
					else {
						flag=0;
						//break;
					}
				}
				if(flag==1) {
				System.out.println("Element Fount at "+i);
				}
				else {
					System.out.println("Element Not Found");
				}
				
			}

		


	}


