package com.example;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

public class StudentDAO {
	private JdbcTemplate temp;
	public void setTemp(JdbcTemplate temp) {
		this.temp = temp;
	}

	/*Driver ->connection -> statement ->execute -> close  */

	//Driver ->connection[spring.xml]
	//Inserting values into student table
	public int insert(Student sobj) {
		//String sql="insert into student values("+sobj.getSid()+",'"+sobj.getSname()+",'"+sobj.getSemail()+'")";
		String sql="insert into student values("+sobj.getSid()+",'"+sobj.getSname()+"','"+sobj.getSemail()+"')";
		//insert update delete 
		return temp.update(sql);
	}
	
	public int delete(Student sobj) {
		//String sql="insert into student values("+sobj.getSid()+",'"+sobj.getSname()+",'"+sobj.getSemail()+'")";
		//String sql="insert into student values("+sobj.getSid()+",'"+sobj.getSname()+"','"+sobj.getSemail()+"')";
		String sql="delete from student where sid=sobj.getSid()";
		//insert update delete 
		return temp.update(sql);
	}
	
	
	
	
	
	
	//Retreiving records from table
	public List<Student> getallStudents(){
		String sql="select * from student";
		return temp.query(sql, new ResultSetExtractor<List<Student>>() {

			@Override
			public List<Student> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<Student> list=new ArrayList<>();

				while(rs.next()) {
					Student stu=new Student();
					stu.setSid(rs.getInt(1));
					stu.setSname(rs.getString(2));
					stu.setSemail(rs.getString(3));
					list.add(stu);
					
				}



				return list;
			}



		});


	}
		}
