package com.example;


import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		//ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		Student s=ac.getBean(Student.class);
		StudentDAO sdao=ac.getBean(StudentDAO.class);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student id");
		s.setSid(sc.nextInt());
		System.out.println("Enter Student Name");
		s.setSname(sc.next());
		System.out.println("Enter Student email");
		s.setSemail(sc.next());
		if(sdao.insert(s)>0) {
		System.out.println("inserted the record into the student table ");
		}
	else {
		System.out.println("insertion failed ");
		}
		List<Student> getall=sdao.getallStudents();
		for(Student student:getall) {
			System.out.println(student);
		}


	}

}
