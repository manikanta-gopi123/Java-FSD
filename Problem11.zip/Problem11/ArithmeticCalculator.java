package Problem11;

import java.util.Scanner;

public class ArithmeticCalculator 
{ 

	void addition(int number1,int number2) {
		int result=number1+number2;
		System.out.println("Addition of Two Numbers is : "+result);
	}
	void subtraction(int number1,int number2) {
		int result=number1-number2;
		System.out.println("Subtraction of Two Numbers is : "+result);
	}
	void multiplication(int number1,int number2) {
		int result=number1*number2;
		System.out.println("Multiplication of Two Numbers is : "+result);
	}
	void division(int number1,int number2) {
		int result=number1/number2;
		System.out.println("Division of Two Numbers is : "+result);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Any one option");
		System.out.println(" 1)Addition\n 2)Subtraction\n 3)Multiplication\n 4)Division");
		int option=sc.nextInt();
		System.out.println("Enter Two Numbers");
		int number1=sc.nextInt();
		int number2=sc.nextInt();
		ArithmeticCalculator obj=new ArithmeticCalculator();
		

		if(option==1) {
			obj.addition(number1, number2);
		}
		else if(option==2) {
			obj.subtraction(number1, number2);
		}
		else if(option==3) {
			obj.multiplication(number1, number2);

		}
		else if(option==4) {
			obj.division(number1, number2);
		}
		else {
			System.out.println("Enter The Correct Option");
		}

	}

}
