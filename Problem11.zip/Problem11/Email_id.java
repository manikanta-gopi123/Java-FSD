package Problem11;

import java.util.Scanner;

public class Email_id {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String emailarray[]= {
				"Gopi@gmail.com",
				"mani@gmail.com",
				"nadi@gmail.com",
				"gopi123@gmail.com"
		};
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter email id to verify");
		String se=sc.next();
		int temp=0;
		for(int i=0;i<=emailarray.length;i++) {
			if(se.equals(emailarray[i])) {
				temp=1;
				break;
			}
		}
		if(temp==1) {
			System.out.println("Valid Email");
		}
		else {
			System.out.println("Invalid Email");
		}

	}

}
