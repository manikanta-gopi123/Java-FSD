package com.pojo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	    public static void main(String[] args) {
	        Configuration configuration = new Configuration().configure();
	        SessionFactory sessionFactory = configuration.buildSessionFactory();

	        Session session = sessionFactory.openSession();
	        Transaction transaction = session.beginTransaction();

	        // Create a person with lazy-loaded addresses
	        Person person = new Person();
	        person.setName("John Doe");

	        Address address1 = new Address();
	        address1.setCity("City1");
	        address1.setStreet("Street1");
	        address1.setPerson(person);

	        Address address2 = new Address();
	        address2.setCity("City2");
	        address2.setStreet("Street2");
	        address2.setPerson(person);

	        person.getAddresses().add(address1);
	        person.getAddresses().add(address2);

	        session.save(person);

	        transaction.commit();
	        session.close();

	        // Access the lazy-loaded collection in a new session
	        session = sessionFactory.openSession();
	        transaction = session.beginTransaction();

	        Person retrievedPerson = session.get(Person.class, person.getId());

	        // The addresses collection is loaded when accessed for the first time
	        List<Address> addresses = retrievedPerson.getAddresses();
	        System.out.println("Addresses: " + addresses);

	        transaction.commit();
	        session.close();

	        sessionFactory.close();
	    }
	}


