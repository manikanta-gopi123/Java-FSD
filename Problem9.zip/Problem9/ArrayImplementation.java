package Problem9;

import java.util.Scanner;

public class ArrayImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of an array");
		int n=sc.nextInt();
		System.out.println("Enter Elements into array");
		int array[]=new int[n];
		for(int i=0;i<n;i++) {
			array[i]=sc.nextInt();
		}
		
		for(int i=0;i<n;i++) {
			System.out.println("Array Elements are : "+array[i]);
			
		}

	}

}
