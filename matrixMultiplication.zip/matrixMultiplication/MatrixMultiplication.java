package com.matrixMultiplication;

import java.util.Scanner;

public class MatrixMultiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int Mat1[][]= {
				{1,2,3},{4,5,6},{6,7,8}
		};
		int Mat2[][]= {
				{1,3,5},{5,6,5},{4,8,3}
		};
		int Mat3[][]=new int[3][3];
		for(int i=0;i<3;i++) {
			for(int j=0;i<3;j++) {
				Mat3[i][j]=0;
				for(int k=0;k<3;k++) {
						Mat3[i][j]=Mat1[i][j]*Mat2[i][j];
				}
				System.out.println(Mat3[i][j]+" ");
			}
			System.out.println();
		}
		
		
	}

}
