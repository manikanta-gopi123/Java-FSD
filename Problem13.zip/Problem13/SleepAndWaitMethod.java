package Problem13;

public class SleepAndWaitMethod {
	

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		final Object lock=new Object();
		Thread t1=new Thread(() -> {
			synchronized (lock) {
				System.out.println("This thread is going to sleep for 2 sec");
				try {
					Thread.sleep(2000);
				}
				catch(Exception e) {
					e.printStackTrace();
					}
				System.out.println("Thread 1 has woken up...");
			}
		});
		Thread t2=new Thread(()->{
			synchronized(lock) {
				System.out.println("Thread2 is in waiting Mode");
				try {
					lock.wait();
					}
				catch(Exception e) {
				e.printStackTrace();	
				}
				System.out.println("Thread 2 has been noticed");
				}
		});
		t1.start();
		t2.start();
		try {
			Thread.sleep(1000);
		}
			catch(Exception e) {
				e.printStackTrace();
			}
		synchronized(lock) {
			System.out.println("Main Thread is noticing Thread 2");
			lock.notify();
		}
	
		

	}

}
