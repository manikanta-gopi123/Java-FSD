package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
Person p=new Person();
        //Person person = new Person();
        p.setName("Gopi");

        Address address1 = new Address();
        address1.setCity("City1");
        address1.setStreet("Street1");

        Address address2 = new Address();
        address2.setCity("City2");
        address2.setStreet("Street2");

        p.getAddressesList().add(address1);
        p.getAddressesList().add(address2);

        p.getAddressesSet().add(address1);
        p.getAddressesSet().add(address2);

        p.getAddressesMap().put("Home", address1);
        p.getAddressesMap().put("Work", address2);

        session.save(p);

        transaction.commit();
        session.close();

        session = sessionFactory.openSession();
        transaction = session.beginTransaction();

        Person retrievedPerson = session.get(Person.class, p.getId());
        System.out.println("Retrieved Person: " + retrievedPerson.getName());
        System.out.println("Addresses List: " + retrievedPerson.getAddressesList());
        System.out.println("Addresses Set: " + retrievedPerson.getAddressesSet());
        System.out.println("Addresses Map: " + retrievedPerson.getAddressesMap());

        transaction.commit();
        session.close();

        sessionFactory.close();

	}

}
