package com.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Person {
	 private Long id;
	    private String name;
	    private List<Address> addressesList = new ArrayList<>();
	    private Set<Address> addressesSet = new HashSet<>();
	    private Map<String, Address> addressesMap = new HashMap<>();
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public String setName(String name) {
			return this.name = name;
		}
		public List<Address> getAddressesList() {
			return addressesList;
		}
		public void setAddressesList(List<Address> addressesList) {
			this.addressesList = addressesList;
		}
		public Set<Address> getAddressesSet() {
			return addressesSet;
		}
		public void setAddressesSet(Set<Address> addressesSet) {
			this.addressesSet = addressesSet;
		}
		public Map<String, Address> getAddressesMap() {
			return addressesMap;
		}
		public void setAddressesMap(Map<String, Address> addressesMap) {
			this.addressesMap = addressesMap;
		}
		
}
