package Problem5;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class CollectionImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> ArrayList=new ArrayList<>();
		ArrayList.add("Gopi");
		ArrayList.add("Mani");
		ArrayList.add("Apple");
		ArrayList.add("Orange");
		ArrayList.add("Lemon");
		System.out.println("Elements Present in the ArrayList are : "+ArrayList);
		System.out.println(ArrayList.contains("Gopi"));
		System.out.println(ArrayList.contains("Gopi123"));
		System.out.println(ArrayList.indexOf("Mani"));
		System.out.println(ArrayList.isEmpty());
		
		
		
		
		
		System.out.println("===============================================");
		System.out.println("LinkedList");
		List<String> LinkedList=new LinkedList<>();
		LinkedList.add("Gopi");
		LinkedList.add("Hii");
		LinkedList.add("Apple");
		LinkedList.add("Hello");
		LinkedList.add("Lemon");
		System.out.println("Elements Present in the ArrayList are : "+LinkedList);
		System.out.println(LinkedList.contains("Gopi"));
		System.out.println(LinkedList.contains("Gopi123"));
		System.out.println(LinkedList.indexOf("Mani"));
		System.out.println(LinkedList.isEmpty());
		

	}

}
