package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;




/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	//register the web driver =>browser vendor 
        WebDriverManager.chromedriver().setup();
        //creating an object to the object
        WebDriver wd=new ChromeDriver();
        //maximize the browser
        wd.manage().window().maximize();
        
        //go to browser and open this url 
        wd.get("https://www.flipkart.com/");
        //wd.findElement(By.id("input")).sendKeys("Gopi");
        //wd.findElement(By.className("input"));
        //wd.findElement(By.xpath("//*[@id=\"input\"]"));
        //wd.findElement(By.id("submit"));
        //wd.close();4
        //wd.findElement(By.id("portal--container")).sendKeys("iphone");
        
       
        
    }
}
