package com.CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.jdbc.JdbcConstantPool;

public class DropDataBase {

	public static void main(String[] args) throws SQLException {
		Connection connection=DriverManager.getConnection(JdbcConstantPool.Driver_Url,
				JdbcConstantPool.username,JdbcConstantPool.password);
		Statement statement=connection.createStatement();
		statement.executeUpdate("DROP DATABASE db1");
		System.out.println("DataBase Created SucessFylly");
	}

}
