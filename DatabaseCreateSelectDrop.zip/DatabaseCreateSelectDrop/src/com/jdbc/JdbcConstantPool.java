package com.jdbc;

public class JdbcConstantPool {
	public static final String Driver_Class="com.mysql.cj.jdbc.Driver";
	public static final String Driver_Url="jdbc:mysql://localhost:3306/phase2";
	public static final String username="root";
	public static final String password="Gopi@123";

}
