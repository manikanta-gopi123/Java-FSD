package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcUtil {
	public static Connection conn() throws SQLException, ClassNotFoundException {
		//Register the Driver
		Class.forName(JdbcConstantPool.Driver_Class);
		//Connnect with database
		Connection conn=DriverManager.getConnection(JdbcConstantPool.Driver_Url,JdbcConstantPool.username,JdbcConstantPool.password);
		return conn;
	}

}
