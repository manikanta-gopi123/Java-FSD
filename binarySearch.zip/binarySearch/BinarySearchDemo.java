package com.binarySearch;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearchDemo {

	public static void main(String[] args) {
				int arr[]=new int[] {
						25,30,9,48,75};
				Arrays.sort(arr);//This is an inbuilt method to sort array 
				for(int i:arr) {
					System.out.print(i+" ");
				}
				System.out.println();
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter Key to search");
				int key=sc.nextInt();
				int flag=0;
				//int i=0;
				int low=0;
				int high=arr.length-1;
				int mid=0;
				while(low<=high) {
				mid=(low+high)/2;
				if(arr[mid]==key) {
					flag=1;
					break;
				}
				else if(arr[mid]<key){
					low=mid+1;
				}
				else {
					high=mid-1;
				}
				}
				
				if(flag==1) {
					System.out.println("element is found at index "+mid);
				}
				else {
					System.out.println("element is not found ");
				}
			}


			



	}


