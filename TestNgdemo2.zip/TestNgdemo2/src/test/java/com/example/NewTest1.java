package com.example;

import org.testng.annotations.Test;

public class NewTest1 {

	@Test
	public void test3() {
		System.out.println("test3 intiated ");
		
	}
	
	
	@Test
	public void test4() {
		System.out.println("test4 intiated ");
	}
	
}
