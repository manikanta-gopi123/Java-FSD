package com.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewTest {
	
	
	@Test
	public void test1() {
		System.out.println("test1 intiated ");
		
	}
	
	
	@Test
	public void test2() {
		System.out.println("test2 intiated ");
	}
	
	
	@Test
	public void test6() {
		System.out.println("test6 intiated ");
	}
	
	
}
