package com.queue;

import java.util.LinkedList;
import java.util.Queue;

public class QueueImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<String> q=new LinkedList<>();
		q.add("Gopi");
		q.add("Manianta");
		q.add("Hamenth");
		q.add("GopiManiknta");
		System.out.println("Elements Present in the queue are : "+ q);
		String str=q.remove();
		System.out.println("Element removed from the quere are : "+ str);
		System.out.println("Updated Queue is  : "+ q);
		q.add("Nadikatla");
		System.out.println("Elements Present in the queue are : "+ q);

	}

}
