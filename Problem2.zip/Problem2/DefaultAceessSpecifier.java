package Problem2;

public class DefaultAceessSpecifier {
	void display() {
		System.out.println("This is Default Access Specifier");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultAceessSpecifier obj=new DefaultAceessSpecifier();
		obj.display();

	}

}
