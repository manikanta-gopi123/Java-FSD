package Problem2;

public class PrivateAccesSpecifier {
	private void display() {
		System.out.println("This is Private Access Specifier");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateAccesSpecifier obj=new PrivateAccesSpecifier();
		obj.display();

	}

}
