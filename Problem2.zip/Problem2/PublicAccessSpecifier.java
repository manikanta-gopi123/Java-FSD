package Problem2;

public class PublicAccessSpecifier {
	public void display() {
		System.out.println("This is public Access Specifier");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PublicAccessSpecifier  obj=new PublicAccessSpecifier();
		obj.display();

	}

}
