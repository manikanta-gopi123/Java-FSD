package Problem2;

public class ProtectedAccessSpecifier {
	protected void display() {
		System.out.println("This is Protected Access Specifier");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProtectedAccessSpecifier  obj=new ProtectedAccessSpecifier();
		obj.display();
		

	}

}
